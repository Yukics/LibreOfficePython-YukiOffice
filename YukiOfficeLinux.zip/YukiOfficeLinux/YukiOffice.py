'''Primero de todo, este programa lo he hecho para que funcione de la forma mas eficiente posible,
por ello no he utilizado ni objetos ni nada ademas asi es mas facil a la hora de leer y entender 
sobretodo si no estas acostumbrado a leer codigo.


GNU GPL 3.0 '''


#Libreria de interfaz gráfica, debe instalarse (sudo apt-get install python3-tk para tkinter )
import tkinter as tk
from tkinter.filedialog import askopenfilename
from PIL import Image

#Librerias de sistema
import os, time

#Libreria que permite paralelizar procesos
from threading import Thread

#Ejecuta los procesos en paralelo
def abrir_factura_y_numero():
    Thread(target=abrir_factura).start()
    Thread(target=anadir_numero).start()
    Thread(target=exec_macro).start()
def abrir_plantilla_proceso():
    Thread(target=abrir_plantilla).start()
def abrir_agenda_proceso():
    Thread(target=abrir_agenda).start()
def abrir_albaran_proceso():
    Thread(target=abrir_albaran).start()
def factura_desde_albaran_proceso():
    Thread(target=factura_desde_albaran).start()
def abrir_cfg_proceso():
    Thread(target=abrir_cfg).start()

#No mires esto
def easter_egg():
    img = Image.open('Documentacion/Pruebas y proceso/monoconpistola.jpeg')
    img.show()

#Lineas de comando para ejecutar las plantillas
def abrir_agenda():
    os.system('libreoffice Plantilla/Agenda.odb')
def abrir_plantilla():
    os.system('libreoffice Plantilla/PlantillaEmpresa.ott')
def abrir_albaran():
    os.system('libreoffice --accept="socket,host=localhost,port=2002;urp;" "Plantilla/PlantillaFactura.ots"')
def abrir_factura():
    os.system('libreoffice --accept="socket,host=localhost,port=2002;urp;" "macro://Untitled 1/Standard.AplicarIVA.IVA" "Plantilla/PlantillaFactura.ots"')
def abrir_cfg():
    os.system('gedit config.txt')

#Se jecuta contador.py
def anadir_numero():
    time.sleep(10)
    contador = "python3"+" contador.py"
    #Ruta donde se encuentra el python del LibreOffice con el modulo uno incorporado
    os.system(contador)

#Resta uno a la factura por si me he equivocado, lo he hecho así para que sepa que cada vez que comete un fallo tiene que trabajar mas haciendo click en el boton
def restar_uno_factura():
    #Extrae el numero de factura
    def sacar_cfg():
        config=[]
        with open ('config.txt', 'rt') as archivo_config:  # Abre config.txt en modo lectura
            for line in archivo_config: # Guarda cada linea en una poosicion de la lista
                   config.append(line)
            contador=config[0]
            contador=(contador[config[0].find('=')+1:len(config[0])]).strip()  #Saca el numero contador para las facturas
        return contador

     #Resta 1 al numero de factura
    def restar_uno_contador(contador):
            with open('config.txt', 'rt') as archivo_config:  # Abre config.txt en modo lectura
                filedata = archivo_config.read() #Vuelca el archivo en filedata
            contador_2 = str(int(contador)-1) #Resta uno al contador
            filedata = filedata.replace(contador, contador_2, 1) #Remplaza el nuevo numero contador
            with open('config.txt', 'w') as archivo_config:
                archivo_config.write(filedata) #Sobreescribe el archivo de cfg
    numero=sacar_cfg()
    restar_uno_contador(numero)

#Ejecuta la macro interna del documento sin titulo
def exec_macro():
    time.sleep(11)
    os.system('libreoffice "macro://Untitled 1/Standard.AplicarIVA.IVA"')
		
		
#Extrae el nombre del archivo de una ruta completa, esto existe por culpa de la ejecución de la macro de la hoja de calculo que aplica el IVA
def extraer_nombre(ruta):
    longitud = len(ruta)-4
    contador = longitud
    while ruta[contador] != "/":
        contador -= 1
    nombre = ruta[contador+1:longitud]
    return nombre

#Permite seleccionar el albarán del cual hacer factura
def factura_desde_albaran():
    def abrir_albaran_seleccionado(comando):
        os.system(comando)
    def ejecutar_macro_albaran_seleccionado(comando):
        os.system(comando)

    name = askopenfilename(initialdir="/home", filetypes=(("Hoja de cálculo de LibreOffice", "*.ods"), ("All Files", "*.*")), title="Elige un albarán.")                               
    print(name)
    #Comprueba la extensión del archivo
    ext = name[len(name)-3:len(name)]
    if ext != "ods" and ext != "ots" and ext != "xls" and ext != "xlt" and name != "":
        print("Extension no reconocida")


    #El comando con la ruta del archivo que se quiere convertir a factura
    ejecutar_albaran_a_factura = 'libreoffice --accept="socket,host=localhost,port=2002;urp;" "%s" ' % name
    
    #Saca el nombre del archivo de la ruta entera para usarlo en la macro 
    archivo = extraer_nombre(name)
    print(archivo)
    time.sleep(10)
    macro = 'macro://%s/Standard.AplicarIVA.IVA' % archivo
    print(macro)

    #La ejecucion de la macro como tal
    ejecutar_macro = 'libreoffice "%s"' % macro
    print(ejecutar_macro)
    
    #Intenta ejecutar el comando y en caso de error muestra una ventana de error (solo se muestra en caso de que no se pueda ejecutar por que se es muy inutil)
    try:
        Thread(target=abrir_albaran_seleccionado, args=[ejecutar_albaran_a_factura]).start()
        print("Esto sigue")
    except:
        print("Ha habido un error")
    time.sleep(25)
    Thread(target=ejecutar_macro_albaran_seleccionado, args=[ejecutar_macro]).start()
    Thread(target=anadir_numero).start()
    

#Abre la ventana específica de creación de facturas, tres cuartos de lo mismo que la principal
def ventana_factura():
    window = tk.Toplevel(root)
    window.title("YukiOffice/Factura")
    window.geometry("500x175")
    frame_f = tk.Frame(window)
    frame_f.pack(side=tk.TOP, fill=tk.X)
    window.resizable(0, 0)

    photo5 = tk.PhotoImage(file="Botones/fa.png")
    button5 = tk.Button(frame_f, width=250, height=175, image=photo5, command=factura_desde_albaran_proceso)
    button5.pack(side=tk.LEFT, padx=2, pady=2)
    button5.configure(width=250, height=175)
    button5.image = photo5

    photo6 = tk.PhotoImage(file="Botones/nf.png")
    button6 = tk.Button(frame_f, width=250, height=175, image=photo6, command=abrir_factura_y_numero)
    button6.pack(side=tk.LEFT, padx=2, pady=2)
    button6.configure(width=250, height=175)
    button6.image = photo6

#Programa principal, genera la interfaz gráfica
if __name__ == "__main__":
    root = tk.Tk()
   	
    #El icono que aparece arriba a la izquierda de la ventana
    root.iconphoto(True, tk.PhotoImage(file='Botones/icono.png'))
    #root.wm_iconbitmap('Botones/icono.ico')
    
    
    #Se crea un frame, como un lugar donde poner cosas la agenda y la plantilla de texto
    frame1 = tk.Frame(root)
    frame1.pack(side=tk.TOP, fill=tk.X)
    
    #Se crea un frame, para el boton de la plantilla del albaran y factruas
    frame2 = tk.Frame(root)
    frame2.pack(side=tk.BOTTOM, fill=tk.X)
    
    #Titulo de la ventana y el programa
    root.title("YukiOffice")
    
    #Tamaño de la ventana en pixeles
    root.geometry("500x350")
    root.configure(background="black")
    
    #Que no se pueda modificar el tamaño de la ventana, hacerlo de la otra forma no merecia la pena
    root.resizable(0, 0)

    #Esto es el menu

    menubar = tk.Menu(root)
    menubar.add_command(label="Config", command=abrir_cfg_proceso)
    menubar.add_command(label="La he cagado con la factura, soy improductivo", command=restar_uno_factura)
    menubar.add_command(label="      ", command=easter_egg)
    root.config(menu=menubar)

    #Cada uno de los botones de la interfaz principal
    photo1 = tk.PhotoImage(file="Botones/image10.png")
    button1 = tk.Button(frame1, width=250, height=175, image=photo1, command=abrir_plantilla_proceso)
    button1.pack(side=tk.LEFT, padx=2, pady=2)
    button1.configure(width=250, height=175)
    button1.image = photo1

    photo2 = tk.PhotoImage(file="Botones/image12.png")
    button2 = tk.Button(frame1, width=250, height=175, image=photo2, command=abrir_agenda_proceso)
    button2.pack(side=tk.LEFT, padx=2, pady=2)
    button2.configure(width=250, height=175)
    button2.image = photo2

    photo3 = tk.PhotoImage(file="Botones/image13.png")
    button3 = tk.Button(frame2, width=250, height=175, image=photo3, command=abrir_albaran)
    button3.pack(side=tk.LEFT, padx=2, pady=2)
    button3.configure(width=250, height=175)
    button3.image = photo3

    photo4 = tk.PhotoImage(file="Botones/image14.png")
    button4 = tk.Button(frame2, width=250, height=175, image=photo4, command=ventana_factura)
    button4.pack(side=tk.LEFT, padx=2, pady=2)
    button4.configure(width=250, height=175)
    button4.image = photo4


    root.mainloop()
