#!/bin/bash
cd /home/yuki/Documentos/YukiOfficeLinux
python3 YukiOffice.py
