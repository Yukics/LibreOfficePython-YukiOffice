#!/bin/bash
sudo apt update
sudo apt upgrade
#Instala python y libreoffice necesarios
sudo apt install -y libreoffice libreoffice-script-provider-python uno-libs3 python3-uno python3
#Seleccionamos la carpeta donde se haya LibreOffice
cd /usr/lib/libreoffice/program
#Instalamos también en virtualenv
sudo apt install -y virtualenvwrapper
virtualenv -p /usr/bin/python3.6 --system-site-packages tmp3
#Instalamos pip, tkinter, PIL y gnome-panel
sudo apt-get install python3-pip
sudo apt-get install python3-tk
sudo pip install pillow
sudo apt install gnome-panel
#Crea el bash lanzador del .py
echo "#!/bin/bash
cd `pwd`
python3 YukiOffice.py" > YukiOffice.sh
#Obliga a que los sh puedan ser ejecutados con doble click
gsettings set org.gnome.nautilus.preferences executable-text-activation 'launch'
#Da permisos a to er mundoh para usar ese script
chmod 777 YukiOffice.sh
bash YukiOffice.sh

